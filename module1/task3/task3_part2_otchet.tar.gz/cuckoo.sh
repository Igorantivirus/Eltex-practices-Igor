#!/bin/bash
LOG_FILE="cuckoo.log"
PIPE_PATH=""
for arg in "$@"; do
  if [[ "$arg" == --pishitesuda=* ]]; then PIPE_PATH="${arg#*=}"; fi
done
[ ! -p "$PIPE_PATH" ] && mkfifo "$PIPE_PATH"

echo "$(date '+%Y-%m-%d %H:%M:%S') Startup!" >> "$LOG_FILE"
trap 'echo "$(date "+%Y-%m-%d %H:%M:%S") Shutdown!" >> "$LOG_FILE"; rm -f "$PIPE_PATH"; exit 0' SIGTERM SIGINT

while true; do
    if read -r line < "$PIPE_PATH"; then
        if [[ "$line" == *"how much time do I have?"* ]]; then
            NAME_PID="${line%%:*}"
            N=$(( RANDOM % 9 + 2 ))
            echo "$(date '+%Y-%m-%d %H:%M:%S') $NAME_PID $N" >> "$LOG_FILE"
            echo "$N" > "$PIPE_PATH"
        fi
    fi
done
