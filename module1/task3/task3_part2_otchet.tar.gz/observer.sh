#!/bin/bash
while read -r task_name; do
    [ -z "$task_name" ] && continue
    if ! pgrep -f "$task_name" > /dev/null; then
        [ ! -L "$task_name" ] && ln -s template_task.sh "$task_name"
        nohup "./$task_name" > /dev/null 2>&1 &
        echo "$(date '+%Y-%m-%d %H:%M:%S') Перезапуск: $task_name" >> observer.log
    fi
done < observer.conf
